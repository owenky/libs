#!/bin/sh

ant -f osgify.xml
