The usage, dependency, redistributable status of OSGi relevant files under osgi folder 

-- Usage --
	Script that converts a JIDE distribution that has many different small jars into several OSGi compatible bundle jars.
	Call the script like 'ant -f osgify.xml'

-- Dependency --
	The script requires antcontrib in the ANT_HOME/lib/ folder. antcontrib requires Ant 1.6, or higher.
	The script requires Bnd to be in the ANT_HOME/lib/ folder. It can be got from http://www.aqute.biz/Bnd/Bnd.

-- Misc --
	If you don't want to run the script yourself, the generated distrubution were published on our website at http://www.jidesoft.com/downloads and http://www.jidesoft.com/evaluation .

