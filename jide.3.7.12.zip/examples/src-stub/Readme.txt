Source code stub zip file contains the source code stub for all JIDE source code. If you purchased JIDE source code
license, you should ignore this file and use the complete source code zip file. If you don't JIDE source code license,
you can use this file to make your user experience better by adding this zip file to your Java IDEs. For more details,
please refer to http://www.jidesoft.com/support/src_stub.htm for more information. 

