package gatchan.phpparser.parser;

/**
 * Exception thrown when the parsing should be aborted.
 * 
 * @author Matthieu Casanova
 */
public class ParsingAbortedError extends Error {

}
