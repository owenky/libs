#!/bin/sh

ant -f mavenify.xml -lib .
