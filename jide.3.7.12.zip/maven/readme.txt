The usage, dependency, redistributable status of maven relevant files under maven folder 

-- Usage --
	Script under this folder converts a JIDE distribution into Maven repository structure, complete with pom files into directory repo.
	Call the script like 'ant -f mavenify.xml', or just use the scripts, mavenify.bat in windows and mavenify.sh in *NIX.
	Just copy the generated folder under ~/.m2/repository. 

-- Dependency --
	This script requires the following libs
	
	1. ant-contrib
	   It can be downloaded from http://downloads.sourceforge.net/project/ant-contrib/ant-contrib/1.0b3. 
	   Antcontrib requires Ant 1.6, or higher.
	
	2. script
	   Apache common bean script framework, it can be downloaded from http://download.nextag.com/apache/commons/bsf/binaries
	   Mozilla Rhino, it can be downloaded from https://github.com/downloads/mozilla/rhino/rhino1_7R4.zip 
	
	3. apache common logging
	   It can be downloaded from http://apache.spinellicreations.com//commons/logging/binaries
	   
    To apply those libs, you can put the jars into $ANT_HOME/lib folder, or specify the search path in command by parameter -lib.

    We have included those jars here in this folder, and applied them by parameter -lib in the mavenify.bat. 
	

-- Misc --
	If you don't want to run the script yourself, the generated distribution were published on http://www.jidesoft.com:8081/artifactory.
	If you want to access, please contact sales@jidesoft.com.

